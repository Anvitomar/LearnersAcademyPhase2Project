package com.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.bean.Subjects;
import com.bean.Teachers;

/**
 * Servlet implementation class AssignTeacherController
 */
public class AssignTeacherController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AssignTeacherController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		String name = request.getParameter("name");
		String[] nameArray = name.split(" ");
		
		String subject = request.getParameter("subject");
		
		Configuration con = new Configuration();
		con.configure("hibernate.cfg.xml");
	    SessionFactory sf  = con.buildSessionFactory();
	    Session session=sf.openSession();
		Transaction t= session.beginTransaction();
		
		String hql_teacher= "from Teachers where tname='" + name + "'";
		List<Teachers> teachers = session.createQuery(hql_teacher).list();
		
		String hql_subject = "update Subjects s set s.teachers=:n where s.suname=:sn";
		
		Query<Subjects> query = session.createQuery(hql_subject);
		query.setParameter("n", teachers.get(0));
		query.setParameter("sn", subject);
				
		query.executeUpdate();

		t.commit();
		session.close();
		
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/viewTeacher.jsp");
        dispatcher.forward(request, response); 
	}

}
