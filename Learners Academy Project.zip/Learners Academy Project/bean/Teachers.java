package com.bean;

import java.util.List;


import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Teachers {
	@Id
	@GeneratedValue
	private int tid;
	private String tname;
	
	
	@OneToMany(cascade=CascadeType.ALL, mappedBy="teachers")
	private List<Subjects> listofSub;

	public int getTid() {
		return tid;
	}

	public void setTid(int tid) {
		this.tid = tid;
	}

	public String getTname() {
		return tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	

	public List<Subjects> getListofSub() {
		return listofSub;
	}

	public void setListofSub(List<Subjects> listofSub) {
		this.listofSub = listofSub;
	}

	@Override
	public String toString() {
		return "Teachers [tid=" + tid + ", tname=" + tname + ", listofSub=" + listofSub + "]";
	}
}