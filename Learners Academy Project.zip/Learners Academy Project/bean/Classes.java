package com.bean;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Classes {
@Id
@GeneratedValue
private int cid;


private String cname;

@OneToMany(cascade=CascadeType.ALL,mappedBy="classes")

private List<Students> listOfStu;

@OneToMany(cascade=CascadeType.ALL,mappedBy="classes")

private List<Subjects> listOfSub;

public int getCid() {
	return cid;
}

public void setCid(int cid) {
	this.cid = cid;
}

public String getCname() {
	return cname;
}

public void setCname(String cname) {
	this.cname = cname;
}

public List<Students> getListOfStu() {
	return listOfStu;
}

public void setListOfStu(List<Students> listOfStu) {
	this.listOfStu = listOfStu;
}

public List<Subjects> getListOfSub() {
	return listOfSub;
}

public void setListOfSub(List<Subjects> listOfSub) {
	this.listOfSub = listOfSub;
}

@Override
public String toString() {
	return "Classes [cid=" + cid + ", cname=" + cname + ", listOfStu=" + listOfStu + ", listOfSub=" + listOfSub + "]";
}



}

