package com.bean;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Students {
@Id
	@GeneratedValue
private int stid;

private String fname;
private String lname;

@ManyToOne(cascade=CascadeType.ALL)
@JoinColumn(name="cid")
private Classes classes;

public int getStid() {
	return stid;
}

public void setStid(int stid) {
	this.stid = stid;
}



public String getFname() {
	return fname;
}

public void setFname(String fname) {
	this.fname = fname;
}

public String getLname() {
	return lname;
}

public void setLname(String lname) {
	this.lname = lname;
}

public Classes getClasses() {
	return classes;
}

public void setClasses(Classes classes) {
	this.classes = classes;
}

@Override
public String toString() {
	return "Students [stid=" + stid + ",fname=" + fname + ", lname=" + lname + ", classes="
			+ classes + "]";
}

}
